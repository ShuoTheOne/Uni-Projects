package tests;

import Data.MemoryDatas.MemoryProductData;
import Product.Behaviour.RainbowGlow;
import Product.KeyboardProduct;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class MemoryProductDataTest {
    @Test
    public void getProductsTest(){
        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new RainbowGlow()
        );
        MemoryProductData data = new MemoryProductData();
        data.addProduct(keyboardProduct);
        Assertions.assertEquals(keyboardProduct, data.queryProductByName(keyboardProduct.getName()));
    }




    @Test
    public void addEvenMoreTest(){
        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new RainbowGlow()
        );

        MemoryProductData data = new MemoryProductData();
        data.addProduct(keyboardProduct);

        KeyboardProduct keyboardProduct2 = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new RainbowGlow()
        );

        data.addProduct(keyboardProduct2);

        Assertions.assertEquals(2, data.queryProductByName(keyboardProduct2.getName()).getAmount());


    }


    @Test
    public void buyOnlyOneTest(){
        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new RainbowGlow()
        );
        keyboardProduct.changeAmount(5);
        MemoryProductData data = new MemoryProductData();
        data.addProduct(keyboardProduct);

        data.removeProductByName("LOGITEK");

        Assertions.assertEquals(5, data.queryProductByName(keyboardProduct.getName()).getAmount());
    }

    @Test
    public void buyALotTest(){
        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                6,
                5252,
                3,
                new RainbowGlow()
        );
        keyboardProduct.changeAmount(5);
        MemoryProductData data = new MemoryProductData();
        data.addProduct(keyboardProduct);

        KeyboardProduct keyboard2Product = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new RainbowGlow()
        );
        keyboardProduct.changeAmount(6);
        data.addProduct(keyboardProduct);

        Assertions.assertEquals(24, data.queryProductByName(keyboard2Product.getName()).getAmount());


    }


    @Test
    public void priceIncrease50PercentTest(){

        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                100,
                3,
                new RainbowGlow()
        );
        MemoryProductData data = new MemoryProductData();
        data.addProduct(keyboardProduct);

        data.updateProductPrice(keyboardProduct, 50);

        Assertions.assertEquals(150, data.queryProductByName(keyboardProduct.getName()).getPrice());
    }

    @Test
    public void priceDecrease50PercentTest(){
        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                100,
                3,
                new RainbowGlow()
        );
        MemoryProductData data = new MemoryProductData();
        data.addProduct(keyboardProduct);

        data.updateProductPrice(keyboardProduct, -50);

        Assertions.assertEquals(50, data.queryProductByName(keyboardProduct.getName()).getPrice());
    }
}
