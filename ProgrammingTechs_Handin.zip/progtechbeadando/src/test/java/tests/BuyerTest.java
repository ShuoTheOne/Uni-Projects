package tests;

import Buyer.Buyer;
import Buyer.BuyerImpl;
import Order.Order;
import Order.OrderImpl;
import Product.Behaviour.RainbowGlow;
import Product.KeyboardProduct;
import Warehouse.BasicWarehouse;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

public class BuyerTest {

    @Test
    public void nameExceptionTest(){

        Exception exception = Assertions.assertThrows(RuntimeException.class, () -> {
            Buyer buyer = new BuyerImpl(
                    "V",
                    122,
                    "Hungary",
                    "Toldi út");
        });

        String expectedMessage = "Buyer name cant be lesser than 2 characters";
        String actualMessage = exception.getMessage();

        Assertions.assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void oldafExceptionTest(){

        Exception exception = Assertions.assertThrows(RuntimeException.class, () -> {
            Buyer buyer = new BuyerImpl(
                    "V. Csaba",
                    131,
                    "Hungary",
                    "Toldi út");
        });

        String expectedMessage = "Age cant be more than 130!";
        String actualMessage = exception.getMessage();

        Assertions.assertTrue(actualMessage.contains(expectedMessage));
    }

    @Test
    public void cartTest(){
        Buyer buyer = new BuyerImpl(
                "Vasas Cs",
                122,
                "Hungary",
                "Toldi út");

        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new RainbowGlow()
        );

        buyer.addProductToCart(keyboardProduct);

        Assertions.assertTrue(buyer.getProductsByBuyer().contains(keyboardProduct));

    }

    @Test
    public void orderTest(){
        Buyer buyer = new BuyerImpl(
                "Vasas Cs",
                122,
                "Hungary",
                "Toldi út");

        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new RainbowGlow()
        );

        buyer.addProductToCart(keyboardProduct);

        buyer.orderProducts(BasicWarehouse.getInstance());

    }

}
