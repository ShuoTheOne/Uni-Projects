package tests;

import Buyer.BuyerImpl;
import Buyer.Buyer;
import Order.Order;
import Order.OrderBuilder;
import Product.Behaviour.RainbowGlow;
import Product.KeyboardProduct;
import Warehouse.BasicWarehouse;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.util.List;

public class WarehouseTest {

    @Test
    public void productToBuyerIdTest(){
        BuyerImpl buyer = new BuyerImpl(
                "Vasas Cs",
                122,
                "Hungary",
                "Toldi út");

        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new RainbowGlow()
        );

        BasicWarehouse.getInstance().addBuyer(buyer);

        BuyerImpl buyer1 = new BuyerImpl(
                "Vasas Cs",
                122,
                "Hungary",
                "Toldi út");


        Assertions.assertEquals(
                BasicWarehouse.getInstance().getBuyerByID(buyer.getName()).getName(),
                buyer1.getName()
        );
    }
}
