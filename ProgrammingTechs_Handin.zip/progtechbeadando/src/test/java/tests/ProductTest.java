package tests;

import Product.Behaviour.NoGlow;
import Product.Behaviour.RainbowGlow;
import Product.Behaviour.RedGlow;
import Product.KeyboardProduct;
import Product.MouseProduct;
import Product.Prototype.LaserMouse;
import Product.RamProduct;
import org.junit.jupiter.api.Assertions;
import org.junit.Test;

public class ProductTest {

    @Test
    public void GlowsTest() {

        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new RainbowGlow()
        );
        Assertions.assertEquals(keyboardProduct.glowing(), "Glow");
    }

    @Test
    public void doesntGlowTest(){
        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new NoGlow()
        );
        Assertions.assertEquals(keyboardProduct.glowing(), "NoGlow");
    }

    @Test
    public void glowsREDTest(){
        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                3,
                5252,
                3,
                new RedGlow()
        );
        Assertions.assertEquals(keyboardProduct.glowing(), "Red");
    }

    @Test
    public void increaseThisBy50Test(){
            KeyboardProduct keyboardProduct = new KeyboardProduct(
                    "LOGITEK",
                    3,
                    100,
                    3,
                    new RainbowGlow()
            );
        keyboardProduct.adjustPriceByPercentage(50);
        Assertions.assertEquals(150, keyboardProduct.getPrice());
    }

        @Test
        public void decreaseThisBy50Test(){
            KeyboardProduct keyboardProduct = new KeyboardProduct(
                    "LOGITEK",
                    3,
                    100,
                    3,
                    new RainbowGlow()
            );
            keyboardProduct.adjustPriceByPercentage(-50);
            Assertions.assertEquals(50, keyboardProduct.getPrice());
        }

    @Test
    public void addKeyboardTest(){
        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "LOGITEK",
                1,
                100,
                3,
                new RainbowGlow()
        );
       keyboardProduct.changeAmount(3);
        Assertions.assertEquals(4, keyboardProduct.getAmount());
    }

    @Test
    public void buyRamTest(){
        RamProduct ramProduct = new RamProduct(
                "HyperX 3200",
                3,
                2400,
                2666,
                2
        );
        ramProduct.changeAmount(9);
        ramProduct.changeAmount(-5);
        Assertions.assertEquals(5, ramProduct.getAmount());
    }

    @Test
    public void buyMouseTest(){
        LaserMouse laserMouse = new LaserMouse(
                "HyperX 3200",
                1,
                2400
        );
        laserMouse.changeAmount(9);
        laserMouse.changeAmount(-5);
        Assertions.assertEquals(5, laserMouse.getAmount());
    }
}
