package tests;
import org.junit.jupiter.api.Assertions;
import Buyer.BuyerImpl;
import Order.OrderBuilder;
import Order.Order;
import Product.Behaviour.RainbowGlow;
import Product.KeyboardProduct;
import Product.MouseProduct;
import org.junit.Test;

import java.util.ArrayList;


public class OrderTest {
    @Test
    public void OrderBuilder(){
        BuyerImpl buyer = new BuyerImpl(
                "Haszafülű Alfonz",
                66,
                "Magyarország",
                "Toldi út");

        KeyboardProduct keyboardProduct = new KeyboardProduct(
                "Logitech G201",
                1,
                2000,
                5,
                new RainbowGlow()
        );
        buyer.addProductToCart(keyboardProduct);
        OrderBuilder builder = new OrderBuilder();
        builder.setBuyer(buyer);
        builder.addProductData(buyer.getProductDatas());
        Order order = builder.getOrder();
        Assertions.assertTrue(order.getProductsByBuyer().contains(keyboardProduct));
    }
}
