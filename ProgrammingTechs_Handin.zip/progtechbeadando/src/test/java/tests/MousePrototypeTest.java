package tests;
import Product.Prototype.GorgosMouse;
import org.junit.jupiter.api.Assertions;
import Product.Prototype.LaserMouse;
import org.junit.Test;


public class MousePrototypeTest {
    @Test
    public void giveLaserWhenClonedThenCreateAnotherCloneTest() {
        LaserMouse laserMouse = new LaserMouse(
                "Egérke",
                1,
                300
        );
        laserMouse.setSize(2);
        LaserMouse anotherLaserMouse = (LaserMouse) laserMouse.copy();
        anotherLaserMouse.setSize(2);
        Assertions.assertEquals(laserMouse.getSize(),anotherLaserMouse.getSize());
    }

    @Test
    public void giveGorgoWhenClonedThenCreateAnotherCloneTest() {
        GorgosMouse gorgosMouse = new GorgosMouse(
                "Gergő",
                1,
                300
        );
        gorgosMouse.setSize(6);
        GorgosMouse anotherGorgosMouse = (GorgosMouse) gorgosMouse.copy();
        anotherGorgosMouse.setSize(6);
        Assertions.assertEquals(gorgosMouse.getSize(),anotherGorgosMouse.getSize());
    }

}
