package Warehouse;

import Buyer.Buyer;
import Data.MemoryDatas.MemoryBuyerData;
import Data.MemoryDatas.MemoryOrderData;
import Data.MemoryDatas.MemoryProductData;
import Order.Order;
import Product.Product;

import java.util.List;

public class BasicWarehouse implements Warehouse {

    public BasicWarehouse() {
        memoryProductDatas = new MemoryProductData();
        memoryOrderDatas = new MemoryOrderData();
        memoryBuyerDatas = new MemoryBuyerData();
    }

    private static BasicWarehouse basicWarehouse = null;
    public static BasicWarehouse getInstance(){
        if(basicWarehouse == null){
            basicWarehouse = new BasicWarehouse();
        }
        return basicWarehouse;
    }

    MemoryProductData memoryProductDatas;
    MemoryOrderData memoryOrderDatas;
    MemoryBuyerData memoryBuyerDatas;

    @Override
    public void addProduct(Product product) {
        memoryProductDatas.addProduct(product);
    }

    @Override
    public List<Product> getProducts() {
        return memoryProductDatas.queryProducts();
    }

    @Override
    public Product getProductByName(String name) {
        return memoryProductDatas.queryProductByName(name);
    }

    @Override
    public void addBuyer(Buyer b) {
        memoryBuyerDatas.addBuyer(b);
    }

    @Override
    public List<Buyer> getBuyers() {
        return memoryBuyerDatas.queryBuyers();
    }

    @Override
    public Buyer getBuyerByID(String id) {
        return memoryBuyerDatas.queryBuyerByName(id);
    }

    @Override
    public void addOrder(Order o) {
        memoryOrderDatas.addOrder(o);
    }

    @Override
    public List<Order> getAllOrder() {
       return memoryOrderDatas.queryOrders();
    }

    @Override
    public Order getOrderByID(int id) {
        return memoryOrderDatas.queryOrderById(id);
    }

    @Override
    public void orderAddToBuyer(String name) {
        memoryBuyerDatas.queryBuyerByName(name).orderProducts(this);
    }

    @Override
    public void addOrderToBuyerByName(String name) {
        memoryBuyerDatas.queryBuyerByName(name).orderProducts(this);
    }

    @Override
    public void addProductToBuyerByName(Product product, String name) {
        memoryBuyerDatas.queryBuyerByName(name).addProductToCart(product);
    }
}
