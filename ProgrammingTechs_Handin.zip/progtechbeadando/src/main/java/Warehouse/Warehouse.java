package Warehouse;

import Buyer.Buyer;
import Order.Order;
import Product.Product;

import java.util.List;

public interface Warehouse {
    void addProduct(Product product);
    List<Product> getProducts();
    Product getProductByName(String name);

    void addBuyer(Buyer b);
    List<Buyer> getBuyers();
    Buyer getBuyerByID(String id);

    void addOrder(Order o);
    List<Order> getAllOrder();
    Order getOrderByID(int id);
    void orderAddToBuyer(String name);

    void addOrderToBuyerByName(String name);
    void addProductToBuyerByName(Product product, String name);
}
