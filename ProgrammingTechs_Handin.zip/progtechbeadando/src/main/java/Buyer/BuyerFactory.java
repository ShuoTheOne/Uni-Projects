package Buyer;

public interface BuyerFactory {

    Buyer createBuyer(String name, int age, String country,  String address);
}
