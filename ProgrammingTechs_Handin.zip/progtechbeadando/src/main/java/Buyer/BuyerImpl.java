package Buyer;

import Data.MemoryDatas.MemoryProductData;
import Exceptions.TooFewException;
import Exceptions.TooMuchException;
import Order.OrderBuilder;
import Product.Product;
import Warehouse.Warehouse;

import java.util.ArrayList;
import java.util.List;

public class BuyerImpl implements Buyer {

    public BuyerImpl(String name, int age, String country, String address) {
        this.setName(name);
        this.setAge(age);
        this.setCountry(country);
        this.setAddress(address);
        cart = new MemoryProductData();
    }

    private String name;

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public void setName(String name) {
        if (name == null) {
            throw new RuntimeException("Buyer name cant be null!");
        }
        if (name.length() < 2) {
            throw new TooFewException("Buyer name cant be lesser than 2 characters");
        }
        this.name = name;
    }

    private int age;

    @Override
    public int getAge() {
        return this.age;
    }

    @Override
    public void setAge(int age) {
        if (age < 0) {
            throw new TooFewException("Age cant be lesser than 0!");
        }
        if (age > 130) {
            throw new TooMuchException("Age cant be more than 130!");
        }
        this.age = age;
    }

    private String country;

    @Override
    public String getCountry() {
        return this.country;
    }

    @Override
    public void setCountry(String country) {
        if (country == null) {
            throw new RuntimeException("Buyer country cant be null!");
        }
        if (country.length() < 2) {
            throw new TooFewException("Buyer country cant be lesser than 2 characters");
        }
        this.country = country;
    }

    private String address;

    @Override
    public String getAddress() {
        return this.address;
    }

    @Override
    public void setAddress(String address) {
        if (address == null) {
            throw new RuntimeException("Buyer address cant be null!");
        }
        if (address.length() < 2) {
            throw new TooFewException("Buyer address cant be lesser than 2 characters");
        }
        this.address = address;
    }


    private MemoryProductData cart;

    public MemoryProductData getProductDatas() {
        return this.cart;
    }
    @Override
    public void addProductToCart(Product product) {
        cart.addProduct(product);
    }

    @Override
    public List<Product> getProductsByBuyer() {
        List<Product> temp = new ArrayList<>();
        for (Product product : cart.queryProducts()) {
            temp.add(product);
        }
        return temp;
    }

    public void orderProducts(Warehouse warehouse) {
        if (cart.queryProducts().size() == 0) {
            throw new TooFewException("Cart is empty");
        }
        OrderBuilder builder = new OrderBuilder();
        builder.setBuyer(this);
        builder.addProductData(this.cart);
        warehouse.addOrder(builder.getOrder());
    }


}
