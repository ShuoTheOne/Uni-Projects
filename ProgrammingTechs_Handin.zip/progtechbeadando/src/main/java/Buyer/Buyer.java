package Buyer;

import Product.Product;
import Warehouse.Warehouse;

import java.util.List;

public interface Buyer {

    String getName();
    void setName(String name);

    int getAge();
    void setAge(int age);

    String getCountry();
    void setCountry(String country);

    String getAddress();
    void setAddress(String address);

    List<Product> getProductsByBuyer();
    void addProductToCart(Product product);

    void orderProducts(Warehouse warehouse);

}
