package Buyer;

public class BuyerFactoryImpl implements BuyerFactory{

    private static BuyerFactoryImpl buyerFactory=null;
    private BuyerFactoryImpl() {
    }

    public static BuyerFactoryImpl getInstance(){
        if(buyerFactory==null){
            buyerFactory=new BuyerFactoryImpl();
        }
        return buyerFactory;
    }


    @Override
    public Buyer createBuyer(String name, int age, String country, String address) {
        return new BuyerImpl(name, age, country, address);
    }
}
