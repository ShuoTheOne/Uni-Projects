package Product;

import Exceptions.TooFewException;
import Exceptions.TooMuchException;

public class RamProduct extends BasicProduct {
    public RamProduct(String name, int amount, int price, int speed, int size) {
        super(name, amount, price);
        setSpeed(speed);
        setSize(size);
    }

    private int speed;
    public int getSpeed(){
        return speed;
    }

    public void setSpeed(int speed){
        if(speed<64){
            throw new TooFewException("Ram speed cannot be slower than 64mhz");
        }
        if(speed>4200){
            throw new TooMuchException("Ram speed cannot be faster than 4200mhz (we are not there yet...)!");
        }
        this.speed = speed;
    }

    private int size;
    public int getSize(){
        return size;
    }

    public void setSize(int size){
        if(size<1){
            throw new TooFewException("Ram cant be lesser than 1 cm!");
        }
        this.size = size;
    }


}
