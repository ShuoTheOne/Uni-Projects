package Product;

import Exceptions.TooFewException;
import Exceptions.TooMuchException;

public abstract class BasicProduct implements Product {


    public BasicProduct(String name, int amount, int price) {
        setName(name);
        setPrice(price);
        changeAmount(1);
    }

    @Override
    public String getName() {
        return name;
    }

    private String name;
    @Override
    public void setName(String name) {

        if(name==null){
            throw new RuntimeException("A név nem lehet null!");
        }
        if(name.length()<=2) {
            throw new TooFewException("A név legalább 2 karakter hosszú kell legyen!");
        }
        if(name.length()>99) {
            throw new TooMuchException("A név maximum 99 karakter hosszú kell legyen!");
        }
        this.name = name;
    }


    @Override
    public int getAmount() {

        return this.amount;
    }

    private int amount = 0;
    @Override
    public void changeAmount(int amount) {
        int amountChange = this.amount + amount;
        if(amountChange<1){
            throw new TooFewException("Amount cant be lesser than one!");
        }
        this.amount = amountChange;
    }


    @Override
    public int getPrice() {
        return price;
    }

    private int price;
    @Override
    public void setPrice(int price) {
        if(price<0){
            throw new TooFewException("Price cant be lesser than 0!");
        }
        this.price = price;
    }

    @Override
    public void adjustPriceByPercentage(int percentage) {
        double adjustPriceByPercentage = (100 + percentage) / 100.0;
        int newPrice = (int)(this.getPrice() * adjustPriceByPercentage);
        this.setPrice(newPrice);
    }
}
