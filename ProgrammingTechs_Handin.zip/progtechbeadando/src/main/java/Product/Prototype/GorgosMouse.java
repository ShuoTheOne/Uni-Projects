package Product.Prototype;

import Product.MouseProduct;

public class GorgosMouse extends MouseProduct {
    public GorgosMouse(String name, int amount, int price) {
        super(name, amount, price);
    }

    @Override
    public MouseProduct copy(){
        Product.Prototype.GorgosMouse gorgosMouse = new Product.Prototype.GorgosMouse(this.getName(), this.getAmount(), this.getPrice());
        gorgosMouse.setSize(this.getSize());
        return gorgosMouse;
    }
}