package Product.Prototype;

import Product.MouseProduct;

public class LaserMouse extends MouseProduct {
    public LaserMouse(String name, int amount, int price) {
        super(name, amount, price);
    }

    @Override
    public MouseProduct copy(){
    LaserMouse laserMouse = new LaserMouse(this.getName(), this.getAmount(), this.getPrice());
    laserMouse.setSize(this.getSize());
    return laserMouse;
    }
}

