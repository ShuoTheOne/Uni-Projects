package Product;

import Product.Behaviour.IGlowBehaviour;

public class KeyboardProduct extends PeripheriaProduct {
    public KeyboardProduct(String name, int amount, int price, int size, IGlowBehaviour glow) {
        super(name, amount, price, size);
        this.glow = glow;

    }
    IGlowBehaviour glow;
    public String glowing(){
        return glow.glowing();
    }

}
