package Product;

public interface Product {
    String getName();
    void setName(String name);

    int getAmount();
    void changeAmount(int amount);

    int getPrice();
    void setPrice(int price);

    void adjustPriceByPercentage(int percentage);
}
