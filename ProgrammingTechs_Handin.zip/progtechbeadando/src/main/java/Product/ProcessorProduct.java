package Product;

import Exceptions.TooFewException;
import Exceptions.TooMuchException;

public abstract class ProcessorProduct extends BasicProduct {
    public ProcessorProduct(String name, int amount, int price, int speed) {
        super(name, amount, price);
        setSpeed(speed);
    }

    private int speed;
    public int getSpeed(){
        return speed;
    }

    public void setSpeed(int speed){
        if(speed<1){
            throw new TooFewException("Processor cant be slower than 1ghz!");
        }
        if(speed>5){
            throw new TooMuchException("Processor cant be faster than 5ghz (we are not there yet..)!");
        }

        this.speed = speed;
    }
}