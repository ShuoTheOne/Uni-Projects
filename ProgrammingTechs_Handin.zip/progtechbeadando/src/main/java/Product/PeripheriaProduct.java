package Product;

import Exceptions.TooFewException;

public abstract class PeripheriaProduct extends BasicProduct {
    public PeripheriaProduct(String name, int amount, int price, int size) {
        super(name, amount, price);
        setSize(size);
    }


    private int size;

    public PeripheriaProduct(String name, int amount, int price) {
        super(name, amount, price);
    }

    public int getSize(){
        return size;
    }

    public void setSize(int size){
        if(size<1){
            throw new TooFewException("Peripheria cant be smaller than 1!");
        }
        this.size = size;
    }
}
