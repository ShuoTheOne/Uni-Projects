package Product;

public class IntelProduct extends ProcessorProduct {
    public IntelProduct(String name, int amount, int price, int speed) {
        super(name, amount, price, speed);
    }
}
