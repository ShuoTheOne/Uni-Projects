package Product;

public class AmdProduct extends ProcessorProduct {
    public AmdProduct(String name, int amount, int price, int speed) {
        super(name, amount, price, speed);
    }
}
