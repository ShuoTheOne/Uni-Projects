package Product.Behaviour;

public class GreenGlow implements IGlowBehaviour {
    @Override
    public String glowing() {
        return "Red";
    }
}
