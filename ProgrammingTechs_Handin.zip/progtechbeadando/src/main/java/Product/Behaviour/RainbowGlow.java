package Product.Behaviour;

public class RainbowGlow implements IGlowBehaviour {
    @Override
    public String glowing() {
        return "Glow";
    }
}
