package Product.Behaviour;

public interface IGlowBehaviour {
    public String glowing();
}
