package Product.Behaviour;

public class WhiteGlow implements IGlowBehaviour {
    @Override
    public String glowing() {
        return "Red";
    }
}
