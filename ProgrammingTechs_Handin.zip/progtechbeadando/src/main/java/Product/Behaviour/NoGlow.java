package Product.Behaviour;

public class NoGlow implements IGlowBehaviour {
    @Override
    public String glowing() {
        return "NoGlow";
    }
}
