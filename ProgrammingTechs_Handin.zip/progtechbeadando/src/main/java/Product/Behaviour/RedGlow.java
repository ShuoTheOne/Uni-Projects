package Product.Behaviour;

public class RedGlow implements IGlowBehaviour {
    @Override
    public String glowing() {
        return "Red";
    }
}
