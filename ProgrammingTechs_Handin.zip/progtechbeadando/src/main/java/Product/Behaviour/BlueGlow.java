package Product.Behaviour;

public class BlueGlow implements IGlowBehaviour {
    @Override
    public String glowing() {
        return "Red";
    }
}
