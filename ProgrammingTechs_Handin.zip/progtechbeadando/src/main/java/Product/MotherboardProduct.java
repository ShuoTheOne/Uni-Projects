package Product;

import Exceptions.TooFewException;
import Exceptions.TooMuchException;

public class MotherboardProduct extends BasicProduct {
    public MotherboardProduct(String name, int amount, int price) {
        super(name, amount, price);
    }

    private int size;
    public int getSize(){
        return size;
    }

    public void setSize(int size){
        if(size<1){
            throw new TooFewException("Mobo cant be lesser than 1cm!");
        }
        this.size = size;
    }
}
