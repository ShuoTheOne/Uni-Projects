package Product;

public abstract class MouseProduct extends PeripheriaProduct {
    public MouseProduct(String name, int amount, int price, int size) {
        super(name, amount, price, size);
    }

    public MouseProduct(String name, int amount, int price) {
        super(name, amount, price);
    }

    public abstract MouseProduct copy();
}
