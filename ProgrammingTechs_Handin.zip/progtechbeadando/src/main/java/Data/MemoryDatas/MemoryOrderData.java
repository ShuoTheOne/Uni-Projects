package Data.MemoryDatas;

import Data.OrderData;
import Exceptions.ObjectNotFoundException;
import Order.Order;

import java.util.ArrayList;
import java.util.List;

public class MemoryOrderData implements OrderData {

    public MemoryOrderData() {
        orders = new ArrayList<>();
    }

    private List<Order> orders;

    @Override
    public Order queryOrderById(int id) {
        for(Order o : orders){
            if(o.getId() == id)
                return o;
        }
        throw new ObjectNotFoundException("This order does not exist.");
    }

    @Override
    public List<Order> queryOrders() {
        List<Order> temp = new ArrayList<>();
        for(Order o : orders){
            temp.add(o);
        }
        return temp;
    }

    @Override
    public void removeOrderById(int id) {
        for(Order o : orders){
            if(o.getId() == id)
                orders.remove(o);
        }
        throw new ObjectNotFoundException("This order does not exist.");
    }

    @Override
    public void addOrder(Order newOrder) {
        newOrder.setId(orders.size() + 1);
        orders.add(newOrder);
    }
}
