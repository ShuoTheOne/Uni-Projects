package Data.MemoryDatas;

import Data.ProductData;
import Exceptions.ObjectNotFoundException;
import Product.Product;

import java.util.ArrayList;
import java.util.List;

public class MemoryProductData implements ProductData {


    public MemoryProductData() {
        this.products=new ArrayList<Product>();
    }

    List<Product> products;

    @Override
    public Product queryProductByName(String name) {
        for(Product p : products){
            if(p.getName().equals(name))
                return p;
        }
        throw new ObjectNotFoundException("Cannot find product");
    }

    @Override
    public List<Product> queryProducts() {
        List<Product> temp = new ArrayList<>();
        for(Product p : products){
            temp.add(p);
        }
        return temp;
    }

    @Override
    public void addProduct(Product product) {
        for(Product p : products){
            if(p.getName().equals(product.getName())){
                p.changeAmount(product.getAmount());
                return;
            }
        }
        products.add(product);
    }

    @Override
    public void updateProductPrice(Product product, int percentage) {
        for(Product p : products){
            if(p.getName().equals(product.getName())){
                p.adjustPriceByPercentage(percentage);
                return;
            }
        }
        throw new ObjectNotFoundException("Cannot find product");
    }

    @Override
    public void removeProductByProduct(Product product) {
        for (Product actProduct : products) {
            if (actProduct.getName().equals(product.getName())) {
                actProduct.changeAmount(-(product.getAmount()));
                if (actProduct.getAmount() == 0)
                    products.remove(actProduct);
                return;
            }
        }
    }

    @Override
    public void removeProductByName(String name) {
        for(Product p : products){
            if(p.getName().equals(name)){
                p.changeAmount(-1);
                return;
            }
        }
        throw new ObjectNotFoundException("Cannot find product");
    }

    @Override
    public void buyProduct(Product product, int piece) {
        for(Product p : products){
            if(p.getName().equals(product.getName())){
                p.changeAmount(-piece);
                return;
            }
        }
    }

}
