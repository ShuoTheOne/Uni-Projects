package Data.MemoryDatas;

import Buyer.Buyer;
import Data.BuyerData;
import Exceptions.AlreadyExistsException;
import Exceptions.ObjectNotFoundException;

import java.util.ArrayList;
import java.util.List;

public class MemoryBuyerData implements BuyerData {


    public MemoryBuyerData() {
        this.buyers=new ArrayList<Buyer>();
    }

    List<Buyer> buyers;

    @Override
    public Buyer queryBuyerByName(String name) {
        for(Buyer b : buyers){
            if(b.getName().equals(name))
                return b;
        }
        throw new ObjectNotFoundException("This buyer doesnt exist");
    }

    @Override
    public List<Buyer> queryBuyers() {
        List<Buyer> temp = new ArrayList<>();
        for(Buyer b : buyers){
            temp.add(b);
        }
        return temp;
    }

    @Override
    public void removeBuyerByName(String name) {
        for(Buyer b : buyers){
            if(b.getName().equals(name)){
                buyers.remove(b);
                return;
            }
        }
        throw new ObjectNotFoundException("This buyer doesnt exist");
    }

    @Override
    public void updateBuyer(Buyer buyer, Buyer newBuyer) {
        for(Buyer b : buyers){
            if(newBuyer.getName().equals(b.getName()) && !buyer.getName().equals(newBuyer.getName())){
                throw new AlreadyExistsException("This buyer already exists");
            }
        }
        for(Buyer b : buyers){
            if(buyer.getName().equals(b.getName())){
                b.setName(newBuyer.getName());
                b.setAge(newBuyer.getAge());
                b.setCountry(newBuyer.getCountry());
                b.setAddress(newBuyer.getAddress());
                return;
            }
        }
        throw new ObjectNotFoundException("This buyer doesnt exist");
    }

    @Override
    public void addBuyer(Buyer buyer) {
        for(Buyer b : buyers){
            if(b.getName().equals(buyer.getName())){
                throw new AlreadyExistsException("This user already exists");

            }
        }
        buyers.add(buyer);
        return;
    }

    @Override
    public void removeBuyerByBuyer(Buyer buyer) {
        for(Buyer b: buyers){
            if(b.getName().equals(buyer.getName())){
                buyers.remove(b);
                return;
            }
        }
    }
}
