package Data;

import Product.Product;

import java.util.List;

public interface ProductData {
    Product queryProductByName(String name);
    List<Product> queryProducts();

    void removeProductByProduct(Product product);
    void removeProductByName(String name);

    void addProduct(Product product);
    void buyProduct(Product product, int piece);

    void updateProductPrice(Product product, int percentage);
}
