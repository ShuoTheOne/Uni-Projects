package Data;

import Buyer.Buyer;

import java.util.List;

public interface BuyerData {
    Buyer queryBuyerByName(String name);
    List<Buyer> queryBuyers();

    void removeBuyerByBuyer(Buyer buyer);
    void removeBuyerByName(String name);

    void addBuyer(Buyer buyer);

    void updateBuyer(Buyer buyer, Buyer newBuyer);
}
