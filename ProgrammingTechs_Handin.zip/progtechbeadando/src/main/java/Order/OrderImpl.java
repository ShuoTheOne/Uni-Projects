package Order;

import Buyer.Buyer;
import Data.MemoryDatas.MemoryProductData;
import Product.Product;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class OrderImpl implements Order {
    public OrderImpl(int id, Buyer buyer, MemoryProductData products) {
        this.setId(id);
        this.setBuyer(buyer);
        this.products = products;
    }

    public OrderImpl(Buyer buyer, MemoryProductData products) {
        this.setBuyer(buyer);
        this.products = products;
    }

    @Override
    public int getId() {
        return this.id;
    }

    private int id;
    @Override
    public void setId(int id) {
        this.id=id;
    }

    @Override
    public Buyer getBuyer() {
        return this.buyer;
    }
    private Buyer buyer;
    @Override
    public void setBuyer(Buyer buyer) {
        this.buyer = buyer;
    }

    private MemoryProductData products;
    @Override
    public List<Product> getProductsByBuyer() {
        List<Product> temp = new ArrayList<>();
        for(Product p : products.queryProducts()){
            temp.add(p);
        }
        return temp;
    }

}
