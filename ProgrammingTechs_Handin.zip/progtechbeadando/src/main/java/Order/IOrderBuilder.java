package Order;

import Buyer.Buyer;
import Data.MemoryDatas.MemoryProductData;

public interface IOrderBuilder {

    Order getOrder();

    IOrderBuilder setBuyer(Buyer buyer);

    IOrderBuilder addProductData(MemoryProductData memoryProductData);
}
