package Order;

import Buyer.Buyer;
import Data.MemoryDatas.MemoryProductData;

public class OrderBuilder implements IOrderBuilder {
    MemoryProductData memoryProductData;
    Buyer buyer;


    @Override
    public Order getOrder() {
        Order order = new OrderImpl(buyer, memoryProductData);
        return order;
    }

    @Override
    public IOrderBuilder setBuyer(Buyer buyer) {
        this.buyer = buyer;
        return this;
    }

    @Override
    public IOrderBuilder addProductData(MemoryProductData memoryProductData) {
        this.memoryProductData = memoryProductData;
        return this;
    }
}
