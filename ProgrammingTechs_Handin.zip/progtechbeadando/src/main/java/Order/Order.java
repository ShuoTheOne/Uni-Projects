package Order;

import Buyer.Buyer;
import Product.Product;

import java.util.List;

public interface Order {

    int getId();
    void setId(int id);

    Buyer getBuyer();
    void setBuyer(Buyer Buyer);

    List<Product> getProductsByBuyer();
}
