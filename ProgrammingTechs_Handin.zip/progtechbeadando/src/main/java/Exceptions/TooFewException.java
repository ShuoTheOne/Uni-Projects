package Exceptions;

public class TooFewException extends RuntimeException {
    public TooFewException(String message) {
        super(message);
    }
}
