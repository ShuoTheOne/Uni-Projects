package Exceptions;

public class TooMuchException extends RuntimeException {
    public TooMuchException(String message) {
        super(message);
    }
}
