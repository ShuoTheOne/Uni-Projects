package Supplier;

import Product.Product;
import Warehouse.Warehouse;

public interface Supplier {

    String getName();
    int getID();
    void SupplyBySupplier(Product prod, Warehouse w);
}
