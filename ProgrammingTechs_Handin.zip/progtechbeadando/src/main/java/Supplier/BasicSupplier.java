package Supplier;

import Product.Product;
import Warehouse.Warehouse;

public class BasicSupplier implements Supplier{

    private static BasicSupplier basicSupplier = null;
    public static BasicSupplier getInstance(){
        if(basicSupplier == null){
            basicSupplier = new BasicSupplier();
        }
        return basicSupplier;
    }


    public String name;
    @Override
    public String getName() {
        return this.name;
    }

    public int id;
    @Override
    public int getID() {
        return this.id;
    }

    @Override
    public void SupplyBySupplier(Product prod, Warehouse w) {
        w.addProduct(prod);
    }
}
